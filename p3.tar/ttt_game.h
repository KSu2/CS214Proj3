int checkWin(char* board);
char* upBoard(char* board,char letter,int* pos);
int valid_move(char*, int, int, char, char);
char* showBoard(char* board);
void init_board(char* board);